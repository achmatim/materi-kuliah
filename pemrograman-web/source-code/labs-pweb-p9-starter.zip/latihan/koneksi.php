<?php
$host = "localhost";    //alamat server
$user = "root";         // user ke db
$pass = "qwerty";       //password ke db
$dbnm = "pweb-mahir";   //nama database

$conn = mysqli_connect($host, $user, $pass, $dbnm);

if (!$conn) {
    die('Koneksi DB gagal');
}
?>