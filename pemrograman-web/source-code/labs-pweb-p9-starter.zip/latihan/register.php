<article>
    <h1>Register New User</h1>
    <p>Isi form pendaftar user dengan benar</p>
    <form action="" method="post">
        <input type="text" name="username" placeholder="Username" /><br/><br/>
        <input type="password" name="password" placeholder="Password" /><br/><br/>
        <input type="nama" name="nama" placeholder="Nama Lengkap" /><br/><br/>
        <input type="email" name="email" placeholder="Alamat Email" /><br/><br/>
        <input type="submit" name="daftar" value="Daftar" />
    </form>
    <?php 
    if (isset($_POST['daftar'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $nama = $_POST['nama'];
        $email = $_POST['email'];

        include_once "koneksi.php";

        $query = "INSERT INTO users 
            VALUES ('$username', MD5('$password'), '$nama', 
            '$email', NOW() ) ";
        
        $exequery = mysqli_query($conn, $query) or die($query);
        if ($exequery) {
            $pesan = "Pendaftaran berhasil. Silahkan login";
        } else {
            $pesan = "Pendaftaran gagal.";
        }
        echo "<script>
        alert('$pesan');
        document.location='index.php';
        </script>";
    }
    ?>
</article>