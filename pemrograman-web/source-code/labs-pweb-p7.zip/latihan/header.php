<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title>Welcome to my site!</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
        <header>
            <h2>Achmatim.Net</h2>
        </header>
        <section>