<?php
include_once 'koneksi.php';
$user_edited = isset($_GET['user'])?$_GET['user']:'';
$query = "SELECT nama, email FROM users WHERE username='$user_edited'";
$sql = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($sql);
$nama = $row['nama'];
$email = $row['email'];
?>
<article>
    <h1>Edit User</h1>
    <p>Isi form register dengan lengkap dan benar</p>
    <form action="" method="post">
        Username: <?php echo $user_edited; ?><br/><br/>
        Nama: <br/><input type="text" name="nama" placeholder="Nama Lengkap" value='<?=$nama?>' /><br/><br/>
        Password: <br/><input type="password" name="password" placeholder="Password" /> *kosongkan jika password tetap (tidak diganti)<br/><br/>
        Email: <br/><input type="email" name="email" placeholder="Email" value='<?=$email?>' /><br/><br/>
        <input type='hidden' name='user_edited' value='<?=$user_edited?>'/>
        <input type="submit" name="edit" value="Edit" />
    </form>
    <?php 
    if (isset($_POST['edit'])) {
        
        $username = addslashes($_POST['user_edited']);
        $nama = addslashes($_POST['nama']);
        $password = $_POST['password'];
        $email = addslashes($_POST['email']);

        //insert ke db
        if (!isset($password) or $password == '') {
            $query = "UPDATE users SET nama='$nama', email='$email' 
                WHERE username='$user_edited'";
        } else {
            $query = "UPDATE users SET nama='$nama', email='$email', password=MD5('$password') 
                WHERE username='$user_edited'";
        }

        $sql = mysqli_query($conn, $query);

        if ($sql) {
            $pesan = "Edit user berhasil.";
            echo "<script>
            alert('$pesan');
            document.location='index.php?page=user';
            </script>";
        } else {
            $pesan = "Edit gagal. Periksa kembali data yang Anda inputkan.";
            echo "<script>
            alert('$pesan');
            document.location='index.php?page=user';
            </script>";
        }
        
    }
    ?>
</article>