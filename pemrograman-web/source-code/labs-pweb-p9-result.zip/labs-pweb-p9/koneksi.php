<?php
$host = "localhost";
$user = "root";
$pass = "qwerty";
$dbnm = "dbweb";

$conn = mysqli_connect($host, $user, $pass, $dbnm);
if (!$conn) {
    die('Koneksi ke Database MySQL gagal');
}
?>