<article>
    <h1>Manajemen User</h1>
    <table border="1" width="100%">
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Created</th>
            <th>Aksi</th>
        </tr>
        <?php
        include_once 'koneksi.php';
        $query = "SELECT * FROM users ORDER BY username";
        $sql = mysqli_query($conn, $query);
        $no = 1;
        while ($row = mysqli_fetch_assoc($sql)) {
            $user = $row['username'];
            $nama = $row['nama'];
            $email = $row['email'];
            $createdate = $row['createdate'];
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $user; ?></td>
            <td><?php echo $nama; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php echo $createdate; ?></td>
            <td><a href='index.php?page=useredit&user=<?=$user?>' title='Edit User'>Edit</a> 
                ~ 
                <a href='index.php?page=userdel&user=<?=$user?>' title='Delete User' onclick="return confirm('Apakah Anda yakin menghapus data ini?')">Delete</a></td>
        </tr>
        <?php } ?>
    </table>
</article>