<article>
    <h1>Login</h1>
    <p>Isi form login dengan benar</p>
    <form action="" method="post">
        <input type="text" name="username" placeholder="Username" /><br/><br/>
        <input type="password" name="password" placeholder="Password" /><br/><br/>
        <input type="submit" name="login" value="Login" />
    </form>
    <?php 
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        include_once "koneksi.php";
        $query = "SELECT COUNT(*) as jumlah FROM users 
            WHERE username='$username' AND password=MD5('$password')";
        $sql = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($sql);
        if ($row['jumlah'] == 1) {
            $pesan = "Login berhasil";
            $_SESSION['ISLOGIN'] = TRUE;
            $_SESSION['USERNAME'] = $username;
        } else {
            $pesan = "Login gagal. Periksa username dan password Anda";
        }
        echo "<script>
        alert('$pesan');
        document.location='index.php';
        </script>";
    }
    ?>
</article>