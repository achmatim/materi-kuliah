<article>
    <h1>Register New User</h1>
    <p>Isi form register dengan lengkap dan benar</p>
    <form action="" method="post">
        Username: <br/><input type="text" name="username" placeholder="Username" /><br/><br/>
        Nama: <br/><input type="text" name="nama" placeholder="Nama Lengkap" /><br/><br/>
        Password: <br/><input type="password" name="password" placeholder="Password" /><br/><br/>
        Email: <br/><input type="email" name="email" placeholder="Email" /><br/><br/>
        <input type="submit" name="register" value="Register" />
    </form>
    <?php 
    if (isset($_POST['register'])) {
        include_once "koneksi.php";
        $username = addslashes($_POST['username']);
        $nama = addslashes($_POST['nama']);
        $password = $_POST['password'];
        $email = addslashes($_POST['email']);

        //insert ke db
        $query = "INSERT INTO users VALUES ('$username', '$nama', MD5('$password'), '$email', NOW())";
        $sql = mysqli_query($conn, $query);

        if ($sql) {
            $pesan = "Pendaftaran user berhasil. Silahkan login";
            echo "<script>
            alert('$pesan');
            document.location='index.php?page=login';
            </script>";
        } else {
            $pesan = "Pendaftaran gagal. Periksa kembali data yang Anda inputkan.";
            echo "<script>
            alert('$pesan');
            document.location='index.php?page=register';
            </script>";
        }
        
    }
    ?>
</article>