<?php
include_once 'koneksi.php';
$user_deleted = isset($_GET['user'])?$_GET['user']:'';

$query = "DELETE FROM users WHERE username='$user_deleted'";
$sql = mysqli_query($conn, $query);
if ($sql) {
    $pesan = "Delete user berhasil.";
    echo "<script>
    alert('$pesan');
    document.location='index.php?page=user';
    </script>";
} else {
    $pesan = "Delete user gagal. Periksa kembali data yang Anda inputkan.";
    echo "<script>
    alert('$pesan');
    document.location='index.php?page=user';
    </script>";
}

?>